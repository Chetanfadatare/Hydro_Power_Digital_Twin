import folium
import pandas as pd
import requests
import time

api_key = 'f3d318f574ae4135acd151116231012'  # Replace with your actual API key
csv_file = "points1.csv"

# Function to get weather data
def get_weather_data(latitude, longitude):
    weather_response = requests.get(
        f'https://api.weatherapi.com/v1/current.json?key={api_key}&q={latitude},{longitude}')
    return weather_response.json()

# Function to create the map and add markers
def create_map(data):
    dam_map = folium.Map(location=[data['Latitude'].mean(), data['Longitude'].mean()], zoom_start=12)
    folium.TileLayer('https://stamen-tiles.a.ssl.fastly.net/watercolor/{z}/{x}/{y}.png', attr='Stamen Watercolor').add_to(
        dam_map)
    folium.TileLayer('cartodbpositron').add_to(dam_map)
    folium.TileLayer('cartodbdark_matter').add_to(dam_map)
    folium.TileLayer('https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}', attr='Google Satellite',
                    name='Google Satellite').add_to(dam_map)

    for index, row in data.iterrows():
        latitude, longitude = row['Latitude'], row['Longitude']
        weather_data = get_weather_data(latitude, longitude)
        popup_text = f"<div style='width: 300px;'><strong>Dam Location</strong><br>"

        if 'temp_c' in weather_data['current']:
            temperature = weather_data['current']['temp_c']
            popup_text += f"Temperature: {temperature}°C<br>"
            if temperature >= 32:
                color = 'red'
            elif 27 <= temperature < 32:
                color = 'orange'
            else:
                color = 'yellow'

        if 'humidity' in weather_data['current']:
            popup_text += f"Humidity: {weather_data['current']['humidity']}%<br>"
        # Add other weather information as needed
        if 'pressure_mb' in weather_data['current']:
            popup_text += f"Pressure: {weather_data['current']['pressure_mb']} hPa<br>"
        if 'condition' in weather_data['current'] and 'text' in weather_data['current']['condition']:
            popup_text += f"Condition: {weather_data['current']['condition']['text']}<br>"
        if 'wind_kph' in weather_data['current']:
            popup_text += f"Wind Speed: {weather_data['current']['wind_kph']} km/h<br>"
        if 'wind_dir' in weather_data['current']:
            popup_text += f"Wind Direction: {weather_data['current']['wind_dir']}<br>"
        if 'cloud' in weather_data['current']:
            popup_text += f"Cloud Cover: {weather_data['current']['cloud']}%<br>"
        if 'precip_mm' in weather_data['current']:
            popup_text += f"Precipitation: {weather_data['current']['precip_mm']} mm<br>"
        if 'vis_km' in weather_data['current']:
            popup_text += f"Visibility: {weather_data['current']['vis_km']} km<br>"
        if 'uv' in weather_data['current']:
            popup_text += f"UV Index: {weather_data['current']['uv']}<br>"
            popup_text += "</div>"

        folium.Marker([latitude, longitude],
                      popup=folium.Popup(popup_text, max_width=350)).add_to(dam_map)

        # Add circles based on temperature conditions
        folium.Circle(radius=1000, location=[latitude, longitude], color=color, fill_color=color).add_to(dam_map)

    # Add layer control to toggle between CSV and cloud layers
    folium.LayerControl().add_to(dam_map)

    # Save the map to an HTML file
    dam_map.save('Final1_map.html')

    # Open the map in a web browser
   

# Infinite loop to update data and map every 5 minutes
while True:
    data = pd.read_csv(csv_file)
    create_map(data)
    time.sleep(300)  # Sleep for 5 minutes
