<!DOCTYPE html>
<html>
<head>
    <title>Required Electricity and Produced Electricity Graph</title>
    <style>
        body {
            background-color: white;
        }
        #myChart {
            width: 100%;   /* Width of the canvas */
            height: 100%;  /* Height of the canvas */
            margin: auto;   /* Center the canvas */
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
<canvas id="myChart"></canvas>
<script>
    var myChart;
    var ctx = document.getElementById('myChart').getContext('2d');
    var allData = [];
    var currentIndex = 0;
    var updateInterval;

    function updateChart() {
        if (currentIndex < allData.length) {
            var currentData = allData[currentIndex];
            myChart.data.labels.push('');
            myChart.data.datasets[0].data.push(parseFloat(currentData.ElectricityRequired));
            myChart.data.datasets[1].data.push(parseFloat(currentData.ElectricityProduced));

            var maxDataPoints = 10; // Maximum number of points on the chart
            if (myChart.data.labels.length > maxDataPoints) {
                myChart.data.labels.shift();
                myChart.data.datasets.forEach((dataset) => {
                    dataset.data.shift();
                });
            }

            myChart.update();
            currentIndex = (currentIndex + 1) % allData.length;
        }
    }

    function initializeChart() {
        myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: [], // x-axis labels (Time)
                datasets: [{
                    label: 'Electricity Required (MW)',
                    data: [], // y-axis data for ElectricityRequired
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Electricity Produced (MW)',
                    data: [], // y-axis data for ElectricityProduced
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: 'black' // Set y-axis labels color to white
                        }
                    },
                    x: {
                        display: false, // Hide the x-axis
                        ticks: {
                            color: 'black' // Set x-axis labels color to white
                        }
                    }
                },
                plugins: {
                    legend: {
                        labels: {
                            color: 'black', // Set dataset label color to white
                            font: {
                                size: 14
                            }
                        }
                    },
                    title: {
                        display: true,
                        text: 'Required Electricity and Produced Electricity',
                        color: 'black', // Set title color to white
                        font: {
                            size: 18
                        }
                    }
                }
            }
        });
    }

    function fetchData() {
        $.ajax({
            url: 'fetch_data1.php',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                console.log('Data fetched:', data); // Debug: Log fetched data
                allData = data;
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', status, error); // Debug: Log AJAX errors
            }
        });
    }

    $(document).ready(function() {
        fetchData();
        initializeChart();
        updateInterval = setInterval(updateChart, 2000); // Update chart every 2 seconds
    });
</script>
</body>
</html>