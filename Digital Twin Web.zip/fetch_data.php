<?php
// Enable error reporting for debugging (disable in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Set the content type to JSON
header('Content-Type: application/json');

// Database credentials (consider moving to a separate config file)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dam";

try {
    // Create a PDO connection
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // Set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Prepare and execute the query
    $stmt = $conn->prepare("SELECT Time, w_in, w_out FROM inout___copy");
    $stmt->execute();

    // Fetch all results
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($results as $key => $value) {
        // Format the Time field to a more readable format if necessary
        $results[$key]['Time'] = date('Y-m-d H:i:s', strtotime($value['Time']));
    }

    if (count($results) > 0) {
        // Output the results
        echo json_encode($results);
    } else {
        http_response_code(404);
        echo json_encode(["error" => "0 results"]);
    }
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(["error" => "Connection failed: " . $e->getMessage()]);
}
?>
