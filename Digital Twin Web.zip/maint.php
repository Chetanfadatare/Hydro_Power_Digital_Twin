<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Climate Data</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background-color: #f0f0f0;
            color: #333;
        }

        header {
            background-color: #2c3e50;
            color: #ecf0f1;
            text-align: center;
            padding: 20px;
        }

        nav {
            background: #3498db;
            display: flex;
            justify-content: center;
            padding: 10px;
        }

        nav a {
            color: #ecf0f1;
            text-decoration: none;
            padding: 15px 20px;
            margin: 0 10px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        nav a:hover {
            background-color: #2980b9;
        }

        section {
            margin: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
            overflow: hidden;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: rgba(0,0,0,0.5);
            color: #ecf0f1;
        }

        footer {
            background-color: #2c3e50;
            color: #ecf0f1;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
        <style>
            body {
                font-family: 'Roboto', sans-serif;
                margin: 0;
                padding: 0;
                box-sizing: border-box;
                background-color: #f0f0f0;
                color: #333;
            }
    
            header {
                padding: 40px;
                background: rgba(0,0,0,0.5);
                
                box-shadow: 0 15px 25px rgba(0,0,0,0.6);
                
              
                color: #ecf0f1;
                text-align: center;
                padding: 20px;
            }
    
            nav {
                background: #3498db;
                display: flex;
                justify-content: center;
                padding: 10px;
                
            }
    
            nav a {
                color: #ecf0f1;
                text-decoration: none;
                padding: 15px 20px;
                margin: 0 10px;
                border-radius: 5px;
                transition: background-color 0.3s ease;
                
            }
    
            nav a:hover {
                background-color: #2980b9;
                
            }
    
            section {
                margin: 20px;
                padding: 40px;
                background: rgba(0,0,0,0.5);
                
                box-shadow: 0 15px 25px rgba(0,0,0,0.6);
            }
    
            table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
                background-color: #fff;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                border-radius: 5px;
                overflow: hidden;
            }
    
            th, td {
                border: 1px solid #ddd;
                padding: 12px;
                text-align: center;
            }
    
            th {
                background-color: #3498db;
                color: #ecf0f1;
            }
    
            footer {
                background-color: #2c3e50;
                color: #ecf0f1;
                text-align: center;
                padding: 10px;
                position: fixed;
                bottom: 0;
                width: 100%;
            }

            html,
body {
	height: 100%;
}

body {
	margin: 0;
	background: linear-gradient(45deg, #49a09d, #5f2c82);
	font-family: sans-serif;
	font-weight: 100;
}



    </style>
</head>
<body>

    <header>
        <h1>Hydro Power Plant Twin Model</h1>
        
    </header>

    <nav>
        <!-- Navigation Links -->
        <a href="http://paramautomationai.com/twin1.php">Twin Model</a>
        
        <a href="http://paramautomationai.com/index1.html">Map</a>
        <a href="http://localhost/SIH/maint.php">Maintainance</a>
    </nav>


    <section id="data">


        <table>
            <tr>
            <th>Equipment Name</th>
                    <th>Last Maintainance Date</th>
                    <th>Next Maintainance Date</th>
                    <th>Status</th>
            </tr>
            <?php
                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $dbname = "sih";

                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $dbname);

                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $sql = "SELECT Eq, Ld, Nd, St FROM main";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        // output data of each row
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $row["Eq"]. "</td>";
                            echo "<td>" . $row["Ld"] . "</td>";
                            echo "<td>" . $row["Nd"]. "</td>";
                            echo "<td>" . $row["St"]. "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4'>No results found</td></tr>";
                    }
                    $conn->close();
                ?>
        </table>
    </section>

    
</body>
</html>
