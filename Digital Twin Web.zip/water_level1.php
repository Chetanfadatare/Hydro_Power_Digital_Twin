<!DOCTYPE html>
<html>
<head>
    <title>Water Level Graph</title>
    <style>
        .container {
            width: 100%;   /* Width of the canvas */
            height: 100%;  /* Height of the canvas */
            margin: auto;
        }

        #myChart {
            background-color: white;
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
    <div class="container">
        <canvas id="myChart"></canvas>
    </div>
    <script>
        var myChart;
        var ctx = document.getElementById('myChart').getContext('2d');
        var allData = [];
        var currentIndex = 0;
        var updateInterval;
        var maxRecords = 11; // Max number of records to display
        var recordCount = 0; // Counter for records

        function updateChart() {
            if (currentIndex < allData.length) {
                var currentData = allData[currentIndex];
                myChart.data.labels.push('');
                myChart.data.datasets[0].data.push(parseFloat(currentData.WaterLevel));

                if (myChart.data.labels.length > maxRecords) {
                    myChart.data.labels.shift(); // Remove oldest x-axis label
                    myChart.data.datasets[0].data.shift(); // Remove oldest data point
                }

                myChart.update();
                currentIndex++;
            }
        }

        function initializeChart() {
            myChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: [],
                    datasets: [{
                        label: 'Water Level',
                        data: [],
                        backgroundColor: 'rgba(255, 99, 132, 0.2)',
                        borderColor: 'rgba(255, 99, 132, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                color: 'black'
                            }
                        },
                        x: {
                            display: false, // Hide the x-axis labels
                            ticks: {
                                color: 'black'
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            labels: {
                                color: 'black',
                                font: {
                                    size: 14
                                }
                            }
                        },
                        title: {
                            display: true,
                            text: 'Water Level Data',
                            color: 'black',
                            font: {
                                size: 18
                            }
                        }
                    }
                }
            });
        }

        function fetchData() {
            $.ajax({
                url: 'waterlevel_fetchdata.php',
                type: 'GET',
                dataType: 'json',
                success: function(data) {
                    console.log('Data fetched:', data);
                    allData = allData.concat(data);
                    if (updateInterval === undefined) {
                        updateInterval = setInterval(updateChart, 2000);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', status, error);
                }
            });
        }

        $(document).ready(function() {
            fetchData();
            initializeChart();
            setInterval(fetchData, 10000);
        });
    </script>
</body>
</html>