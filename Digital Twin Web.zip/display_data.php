<!DOCTYPE html>
<html>
<head>
    <title>Water Inlet Outlet Graph</title>
    <style>
        body {
            background-color: white;
        }
        #myChart {
            width: 100%;   /* Width of the canvas */
            height: 100%;  /* Height of the canvas */
            margin: auto;   /* Center the canvas */
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
<canvas id="myChart"></canvas>
<script>
    var myChart;
    var ctx = document.getElementById('myChart').getContext('2d');
    var allData = [];
    var currentIndex = 0;
    var updateInterval;

    function updateChart() {
        if (currentIndex < allData.length) {
            var currentData = allData[currentIndex];
            myChart.data.labels.push('');
            myChart.data.datasets[0].data.push(parseFloat(currentData.w_in));
            myChart.data.datasets[1].data.push(parseFloat(currentData.w_out));

            var maxDataPoints = 10; // Maximum number of points on the chart
            if (myChart.data.labels.length > maxDataPoints) {
                myChart.data.labels.shift();
                myChart.data.datasets.forEach((dataset) => {
                    dataset.data.shift();
                });
            }

            myChart.update();
            currentIndex = (currentIndex + 1) % allData.length;
        }
    }

    function initializeChart() {
        myChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'w_in',
                    data: [],
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                },
                {
                    label: 'w_out',
                    data: [],
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    x: {
                        display: false, // Hide the x-axis
                    },
                    y: {
                        beginAtZero: true
                    }
                },
                plugins: {
                    legend: {
                        labels: {
                            font: {
                                size: 14
                            }
                        }
                    },
                    title: {
                        display: true,
                        text: 'Water Inlet and Outlet Data'
                    }
                }
            }
        });
    }

    function fetchData() {
        $.ajax({
            url: 'fetch_data.php',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                console.log('Data fetched:', data);
                allData = data;
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', status, error);
            }
        });
    }

    $(document).ready(function() {
        fetchData();
        initializeChart();
        updateInterval = setInterval(updateChart, 2000); // Update chart every 2 seconds
    });
</script>
</body>
</html>