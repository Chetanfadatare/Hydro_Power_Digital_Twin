<?php
// Database credentials
$servername = "localhost";    // Change if your database is hosted on a different server
$username = "root";  // Replace with your MySQL username
$password = "";  // Replace with your MySQL password
$dbname = "sih";    // Replace with your MySQL database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Use the connection to execute SQL queries
// For example, to insert data into a table named "members"
$fname = $_POST['d1'];
$mname = $_POST['d2'];
$lname = $_POST['d3'];
$dob = $_POST['d4'];
$uno = $_POST['d5'];

$sql = "INSERT INTO regestration01 (d1, d2, d3, d4, d5,d mname, lname, dob, uno, gender, eid, mob)
        VALUES ('$fname', '$mname', '$lname', '$dob', '$uno', '$gender', '$eid', '$mob')";

if ($conn->query($sql) === TRUE) {
    echo "New member registered successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the connection
$conn->close();
?>
