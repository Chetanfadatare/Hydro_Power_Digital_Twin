<!DOCTYPE html>
<html>
<head>
    <title>Temperature Speedometer</title>
    <style>
        /* Add your CSS styles here */
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .gauge-container {
            width: 200px;
            height: 100px;
            position: relative;
        }

        .gauge {
            width: 100%;
            height: 100%;
            border-top-left-radius: 200px;
            border-top-right-radius: 200px;
            background: conic-gradient(from 0deg, red 0%, yellow 50%, green 100%);
        }

        .gauge-needle {
            width: 4px;
            height: 50px;
            background: black;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -100%) rotate(0deg);
            transform-origin: center bottom;
            transition: transform 0.5s ease-in-out;
        }

        .gauge-value {
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            position: absolute;
            top: 75%;
            left: 50%;
            transform: translateX(-50%);
        }
    </style>
</head>
<body>
    <div class="gauge-container">
        <div class="gauge">
            <div class="gauge-needle"></div>
        </div>
        <div class="gauge-value">25°C</div>
    </div>
    <script>
        // Function to update the temperature reading and gauge
        function updateTemperature() {
            // Simulate temperature changes (replace with actual data)
            const temperatureReading = Math.floor(Math.random() * 31) - 10; // Random temperature between -10°C and 20°C
            const gaugeValueElement = document.querySelector('.gauge-value');
            const gaugeNeedleElement = document.querySelector('.gauge-needle');

            // Update the gauge value
            gaugeValueElement.textContent = ${temperatureReading}°C;

            // Calculate the rotation angle for the needle based on the temperature
            const minTemperature = -10; // Minimum temperature
            const maxTemperature = 20; // Maximum temperature
            const minRotationAngle = 0; // Angle when temperature is at the minimum
            const maxRotationAngle = 180; // Angle when temperature is at the maximum

            const normalizedTemperature = (temperatureReading - minTemperature) / (maxTemperature - minTemperature);
            const targetRotationAngle = minRotationAngle + normalizedTemperature * (maxRotationAngle - minRotationAngle);

            // Rotate the needle to the target angle
            gaugeNeedleElement.style.transform = translate(-50%, -100%) rotate(${targetRotationAngle}deg);
        }

        // Update temperature every 5 seconds (5000 milliseconds)
        setInterval(updateTemperature, 2000);

        // Initial gauge update
        updateTemperature();
    </script>
</body>
</html>