<?php
$message = "";
if (isset($_GET['param1'])) {
    $message = $_GET['param1']; // $param1 will be 'value1'
}

$host = '127.0.0.1'; // Replace with the IP address of the Unity server
$port = 8052;        // Replace with the port number used in the Unity server

$sock = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
if ($sock === false) {
    echo "socket_create() failed: reason: " . socket_strerror(socket_last_error()) . "\n";
    exit;
}

$result = socket_connect($sock, $host, $port);
if ($result === false) {
    echo "socket_connect() failed.\nReason: " . socket_strerror(socket_last_error($sock)) . "\n";
    socket_close($sock);
    exit;
}

socket_write($sock, $message, strlen($message));
socket_close($sock);
?>